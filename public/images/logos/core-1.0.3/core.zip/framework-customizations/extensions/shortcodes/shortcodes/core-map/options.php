<?php if ( ! defined( 'FW' ) ) die( 'Forbidden' );

$options = _core_get_options_config( 'map' );

?>
