<?php if ( ! defined( 'FW' ) ) die( 'Forbidden' );

echo do_shortcode( $content );

?>
