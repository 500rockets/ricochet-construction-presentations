<?php if ( ! defined( 'FW' ) ) die( 'Forbidden' );

$uri = fw_get_template_customizations_directory_uri( '/extensions/shortcodes/shortcodes/core-pricing-table' );

wp_enqueue_style( 'core-shortcode-pricing-table', $uri . '/static/css/styles.css' );

?>
