<?php if ( ! defined( 'FW' ) ) die( 'Forbidden' );

$manifest = array();

$manifest['title']      = __( 'Core Demo', 'core' );
$manifest['screenshot'] = get_template_directory_uri() . '/demo-content/core-demo/screenshot.png';

?>
