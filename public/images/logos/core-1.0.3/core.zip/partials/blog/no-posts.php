<p><?php _e( 'There are no posts yet.', 'core' ); ?></p>
