<div class="row">
	<div class="col-lg-8 m-auto">
		<p><?php _e( 'There are no projects yet.', 'core' ); ?></p>
	</div>
</div>
