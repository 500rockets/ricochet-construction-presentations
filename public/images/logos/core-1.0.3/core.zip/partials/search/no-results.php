<p><?php _e( 'No results found.', 'core' ); ?></p>
